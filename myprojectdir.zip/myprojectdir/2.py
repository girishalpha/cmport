from flask import Flask, request, render_template, send_from_directory, jsonify, send_file

from flask.wrappers import Request, Response
import re
import sys
import json
import argparse
import threading
from zen import findUsersFromOrganization, flash, findEmailFromUsername, findEmailsFromRepo
from requests import get
from requests.auth import HTTPBasicAuth

app = Flask(__name__, static_folder='./frontend/build/static',
            template_folder='./frontend/build')

inp = ''
breach = ''
output = ''
organization = ''
uname = ''
thread_count = 2

@app.route('/')
def hello_world():
	return 'successfull'

@app.route('/check', methods=['POST'])
def check():
    inp = request.form['inp']
    if inp.endswith('/'):
        inp = inp[:-1]
    targetOrganization = targetRepo = targetUser = False

    if inp.count('/') < 4:
        if '/' in inp:
            username = inp.split('/')[-1]
        else:
            username = inp
        if organization:
            targetOrganization = True
        else:
            targetUser = True
    elif inp.count('/') == 4:
        targetRepo = inp.split('/')
        username = targetRepo[-2]
        repo = targetRepo[-1]
        targetRepo = True
    else:
        print('Invalid input')
        quit()
    jsonOutput = {}
    if targetOrganization:
        usernames = findUsersFromOrganization(username)
        flash(findEmailFromUsername, usernames)
    elif targetUser:
        email = findEmailFromUsername(username)
        return jsonify({"result": email, "error": False})
    elif targetRepo:
        email = findEmailsFromRepo(username, repo)
        return jsonify({"result": email, "error": False})
    if output:
        json_string = json.dumps(jsonOutput, indent=4)
        return jsonify({"result": json_string, "error": False})
        # savefile = open(output, 'w+')
        # savefile.write(json_string)
        # savefile.close()



if __name__ == '__main__':
    app.run()
