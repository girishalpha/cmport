sudo systemctl stop myproject
sleep 1
sudo systemctl disable myproject
sleep 1
sudo systemctl start myproject
sleep 1
sudo systemctl enable myproject
echo "********myproject restart successfull*******"
sudo service nginx restart
echo "Ngnix restart successfull"
